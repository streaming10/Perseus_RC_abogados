---
layout: post
title: "¿Por qué las huellas digitales o patrones faciales no deben entenderse como contraseñas?"
description: "Análisis sobre si el desbloqueo biométrico (huella, Face ID) de un dispositivo está amparado por el derecho a no autoincriminarse (arts. 17.3 y 24.2 CE) y cuándo la policía judicial necesita autorización para acceder a su contenido."
date: 2018-07-30
author: "Luis Jurado Cano"
categories: ["Derecho penal", "Delitos informáticos"]
tags: [biometría, autoincriminación, derechos fundamentales, prueba, registro de dispositivos]
keywords: "desbloqueo biométrico policía, huella dactilar contraseña, no autoincriminación 24.2 CE, registro de móvil autorización judicial, A Coruña"
permalink: /blog/huellas-biometricas-no-son-contrasenas/
---

Desde hace ya varios años se viene planteando esta controversia doctrinal acerca de si las huellas digitales, patrones faciales o cualquier otro sistema de reconocimiento basado en patrones biométricos, se pueden entender dentro del derecho a no confesarse culpable y a no declarar contra sí mismo derivado de los artículos 17.3 y 24.2 CE, así como de lo recogido en los arts. 14 del Pacto Internacional de Derechos Civiles y Políticos y 6 del Convenio Europeo de Derechos Humanos.

Esta disquisición tiene especial relevancia desde que la mayoría de los terminales móviles u ordenadores disponen de sistemas de reconocimiento basados en patrones biométricos que por un lado hacen fácil acceder de forma repetida al contenido del terminal y por otro lado en determinadas situaciones puede provocar que el contenido del mismo pueda ser revisado por terceros dentro del uso de sus funciones derivadas otorgadas por el Estado de derecho como por ejemplo serían las FCSE.

Por eso vamos a diferenciar en  **2 partes**  el acto de acceder por parte de la policía judicial de un terminal que esté encendido y bloqueado. En primer lugar, tendremos el  **acto de desbloquear**  el terminal y en segundo lugar tendremos el hecho de **revisar el contenido del mismo**  para obtener alguna información relevante.

## Desbloqueo

El simple acto de que un sujeto pueda desbloquear un terminal, puede aportar información valiosa a la policía judicial. Porque desde ese momento el sujeto no podrá alegar que no tiene ningún tipo de relación con ese terminal, dado que de forma previa ha tenido que tener acceso al mismo para identificarse -mediante contraseña- y que registre su propio patrón biométrico válido, sea o no, el propietario del mismo.

Dentro de los sistemas de desbloqueo -donde se usan  **factores de autenticación**- a grandes rasgos -citamos algunos ejemplos- tenemos 4 vías:

-   Algo que  **sabe**  el usuario y lo expresa: pin, contraseña, patrón dibujado.
-   Algo que  **hace o resuelve**  el usuario: patrones junto a unos conocimientos muy específicos, una prueba test, cálculos aritméticos, resolver un captcha, etc.
-   Algo que  **tienes**: un token -suele ser un código temporal- por ejemplo, para las transacciones bancarias.
-   Algo que  **eres y no es modificable**: huellas dactilares, iris, patrones faciales, ADN u ondas cerebrales, etc.

Hay que tener claro que  **un patrón de desbloqueo**  se puede realizar a partir de cualquier cosa, siempre que dicho patrón se pueda  **reiterar**  sin alteración -o de forma imperceptible para el dispositivo- a lo largo del tiempo. Y también,  **a ser posible que el dispositivo sólo se desbloquee ante un único individuo**  -el propietario del terminal- o persona autorizada en el mismo. Hay, por tanto, determinados patrones biométricos en el ser humano que indican que un ser humano es él mismo y no es otro individuo -la llamada  **mismidad**, es decir, la condición de ser uno mismo-, que se pueden utilizar y que a su vez cumplen dichas dos condiciones; por ejemplo, las huellas dactilares, el iris, los patrones faciales -como los recogidos por el faceID de Apple y en un futuro no tan lejano los basados en el ADN u ondas cerebrales. Por tanto, habría por un lado  **patrones biométricos que desbloquean el terminal por lo que eres**  y por otro lado  **patrones o contraseñas que implican que manifiestes lo que sabes**. Por hacer un símil, no es lo mismo que te soliciten que reveles tu contraseña, a que te soliciten que entregues un papel donde tengas apuntada la misma.

Para desbloquear un dispositivo que utilice alguno de estos sistemas de reconocimiento biométrico  **no hace falta manifestar o exteriorizar en modo alguno la voluntad del sujeto que quiere desbloquear el dispositivo**. Dicho de otro modo, no hace falta una manifestación volitiva del sujeto propietario del terminal. El propio terminal se desbloquea al detectar que coincide el patrón biométrico con el almacenado de forma previa.

Mientras que para desbloquear un terminal usando la introducción de números -el conocido PIN-, patrones dibujados en la pantalla o introducción de contraseñas, sí hace falta una manifestación exteriorizada de la voluntad del sujeto; en el caso de los patrones biométricos no hace falta la misma, por lo tanto, no pueden quedar amparados por los artículos 17.3 y 24.2 CE, así como los restantes expuestos al inicio.

Entendiendo falta de manifestación al exterior, como el concepto recogido dentro de la teoría del delito; no se considerarán como acción las ideas, pensamientos o propósitos de las personas, por más que los mismos se hallen en relación con un hecho jurídico que sea penalmente no valioso.

## Acceso al contenido del terminal una vez desbloqueado

El motivo de la necesidad de una autorización judicial habilitante es la consideración de estos instrumentos como lugar de almacenamiento de una serie compleja de datos que afectan de modo muy variado a la intimidad del investigado -archivos, fotos, emails, conversaciones-. Esta  **autorización será precisa** en los supuestos en que los **teléfonos móviles se ocupen durante un registro domiciliario**, o sean  **incautados fuera del domicilio del investigado**. La diversa funcionalidad de los datos que se albergan en estos dispositivos provoca una extrema debilidad de la tutela jurisdiccional del derecho del investigado a la reserva de su propio entorno virtual, pues una vez realizado el acceso al dispositivo, superando la barrera de la contraseña o patrón biométrico, todos los datos, incluidos los relacionados con el secreto de las comunicaciones están al libre alcance del investigador.

Si bien la doctrina tiene establecido que  **se admite el examen directo de la agenda de un teléfono móvil por los agentes de la policía judicial**, por estimar que no afecta al derecho al secreto de las comunicaciones sino al derecho a la intimidad (art. 18 CE), también tiene establecido que la injerencia en ese derecho exige que "se encuentre  **justificada**  con arreglo a los  **criterios de urgencia y necesidad**  y que se cumpla el  **requisito de proporcionalidad**  al ponderar los intereses en juego en el caso concreto".

Por eso no vale una respuesta única, si no que habrá que justificar y motivar caso por caso la injerencia en el derecho a la intimidad por el registro policial directo del terminal, cumpliendo siempre de forma justificada con arreglo a los criterios de urgencia y necesidad; pudiendo convertirse en caso de no hacerlo en una prueba de cargo nula, que derive en una no justificación de la condena del acusado. Para ello, es importante que dentro del protocolo policial se contemple, y ante la duda, se solicite la correspondiente orden judicial habilitante para revisar el contenido o extracción de información del dispositivo -siendo necesario que se realice en condiciones idóneas para que no se rompa la cadena de custodia que puedan derivar en otra nulidad de actuaciones-.

Este artículo de mi autoría fue publicado en Legaltoday de Aranzadi-Thomson Reuters el día 30 de julio de 2018. [¿Por qué las huellas digitales o patrones faciales no deben entenderse como contraseñas?](http://www.legaltoday.com/opinion/articulos-de-opinion/por-que-las-huellas-digitales-o-patrones-faciales-no-deben-entenderse-como-contrasenas)

